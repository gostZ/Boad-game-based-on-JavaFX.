package cn.simon;

import cn.simon.dialog.DialogAlter;
import cn.simon.model.Player;
import cn.simon.model.Score;
import cn.simon.model.Tile;
import com.google.gson.*;

import java.io.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;


/**
 * this is a public object implementation class, mainly initialisation of game data.
 *
 * @author Wushuo
 */
public class Common
{


    // Location of the parameter file
    private final String  CONFIGFILE=System.getProperty("user.dir")+System.getProperty("file.separator")+
        "config.json";

    /**
     * TILE_ROWS : Default number of rows in the grid
     * TILE_COLS : Default number of columns in the grid
     * TRAP_QTY : Default number of traps
     * FIRE_QTY : Default number of fires
     * ROOM_QTY : Default number of secret rooms
     * HOLE_QTY : Default number of holes
     * board : Storing grid data
     * playerList : player List
     * jsonParam : Parameter JSON object
     * */
    public int  TILE_ROWS = 8;
    public int  TILE_COLS = 4;
    public int  TRAP_QTY  = 1;
    public int  FIRE_QTY  = 1;
    public int  ROOM_QTY  = 2;
    public int  HOLE_QTY  = 2;
    public Tile[][] board ;
    public List<Player> playerList=new ArrayList<>();
    // List of records
    public List<Score> scoreList=new ArrayList<>();
    // Parameter JSON object
    private JsonObject jsonParam=new JsonObject();
    private final Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd HH:mm:ss").create();

    public Common()
    {
        LoadFile();
    }

    /**
    * @param key    the key of player list in json
    */
    public String getPlayerName(String key)
    {
        try
        {
            return jsonParam.get("users").getAsJsonObject().get(key).getAsString();
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }
        return "";
    }

    public void setPlayerName(String key,String value)
    {
        jsonParam.get("users").getAsJsonObject().addProperty(key,value);
    }

    /**
     * Initialise data.
     * step 1: Creating player objects
     * step 2: Set the player to be initially placed at the maximum row position of the grid
     * step 3: Create a list of records
     * */
    public void InitGame()
    {
        try
        {
            LoadFile();

            board= new Tile[TILE_COLS][TILE_ROWS];

            //Creating player objects
            playerList.clear();
            String playerName=jsonParam.get("users").getAsJsonObject().get("playera").getAsString();
            // Players are initially placed in the largest row of the grid
            Player playerA=new Player(playerName,(TILE_COLS/4),TILE_ROWS,"playera");
            playerA.name=jsonParam.get("users").getAsJsonObject().get("playera").getAsString();
            playerList.add(playerA);

            playerName=jsonParam.get("users").getAsJsonObject().get("playerb").getAsString();
            Player playerB=new Player(playerName,(3*TILE_COLS/4-1),TILE_ROWS,"playerb");
            playerB.name=jsonParam.get("users").getAsJsonObject().get("playerb").getAsString();
            // Determine the length of the list, if it is not empty, the list is created successfully
            playerList.add(playerB);

            // Create a list of records
            scoreList.clear();
            for (JsonElement item : jsonParam.get("scores").getAsJsonArray())
            {
                JsonObject jsonScore=(JsonObject)item;
                Score score=new Score();
                score.player    =jsonScore.get("player").getAsString();
                score.wins      =jsonScore.get("wins").getAsInt();
                score.records   =jsonScore.get("records").getAsInt();
                score.cells     =jsonScore.get("cells").getAsInt();
                score.grade();
                scoreList.add(score);
            }
            // Sorted by number of wins in descending order
            scoreList.sort(Comparator.naturalOrder());
        }
        catch (Exception ex)
        {
            System.out.println("InitGame->error:"+ex.getMessage());
        }
    }

    /**
     * Loading parameters into a JSON object.
     * if josn is empty:
     * Create default player name; Generate an empty list of records; Generate default number of rows and columns
     * Default parameters for generating obstacles
     * */
    private void LoadFile()
    {
        String jsonStr="";
        try
        {
            File file=new File(CONFIGFILE);
            if (file.exists())
            {
                InputStream inputStream = new FileInputStream(file);
                if (inputStream != null) {
                    BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
                    String st;
                    while ((st = br.readLine()) != null) {
                        jsonStr += st;
                    }

                    if (!jsonStr.isBlank()) {
                        jsonParam = JsonParser.parseString(jsonStr).getAsJsonObject();
                    }
                    br.close();
                    inputStream.close();
                }
            }

            if (!jsonParam.has("users"))
            {
                // Create default player name
                JsonObject jsonUser=new JsonObject();
                jsonUser.addProperty ("playera","PlayerA");
                jsonUser.addProperty ("playerb","PlayerB");
                jsonParam.add("users",jsonUser);
                jsonUser=null;
            }

            if (!jsonParam.has("scores"))
            {   // Generate an empty list of records
                jsonParam.add("scores",new JsonArray());
            }

            if (!jsonParam.has("tile"))
            {
                // Generate default number of rows and columns
                JsonObject jsonTile=new JsonObject();
                jsonTile.addProperty("cols",TILE_COLS);
                jsonTile.addProperty("rows",TILE_ROWS);
                jsonParam.add("tile",jsonTile);
                jsonTile=null;
            }
            else
            {
                TILE_COLS=jsonParam.get("tile").getAsJsonObject().get("cols").getAsInt();
                TILE_ROWS=jsonParam.get("tile").getAsJsonObject().get("rows").getAsInt();
            }

            if (!jsonParam.has("hinder"))
            {
                // Default parameters for generating obstacles
                JsonObject jsonHinder=new JsonObject();
                jsonHinder.addProperty("trap",TRAP_QTY);
                jsonHinder.addProperty("fire",FIRE_QTY);
                jsonHinder.addProperty("room",ROOM_QTY);
                jsonHinder.addProperty("hole",HOLE_QTY);
                jsonParam.add("hinder",jsonHinder);
                jsonHinder=null;
            }
            else
            {
                TRAP_QTY=jsonParam.get("hinder").getAsJsonObject().get("trap").getAsInt();
                FIRE_QTY=jsonParam.get("hinder").getAsJsonObject().get("fire").getAsInt();
                ROOM_QTY=jsonParam.get("hinder").getAsJsonObject().get("room").getAsInt();
                HOLE_QTY=jsonParam.get("hinder").getAsJsonObject().get("hole").getAsInt();
            }
        }
        catch (Exception ex)
        {
            System.out.println("LoadFile->error:"+ex.getMessage());
        }
    }

    /**
     * Save the game parameters set by the player to a json file.
     * @param playera Name of playera
     * @param playerb Name of playerb
     * @param cols  Number of board columns
     * @param rows  Number of board rows
     * @param fire  Number of fires
     * @param hole  Number of holes
     * @param room  Number of rooms
     * @param trap  Number of traps
     * */
    public void SavePlayerName(String playera,String playerb,int cols,int rows,int trap,int fire,int room,int hole)
    {
        jsonParam.get("users").getAsJsonObject().addProperty("playera",playera);
        jsonParam.get("users").getAsJsonObject().addProperty("playerb",playerb);

        jsonParam.get("tile").getAsJsonObject().addProperty("cols",cols);
        jsonParam.get("tile").getAsJsonObject().addProperty("rows",rows);

        jsonParam.get("hinder").getAsJsonObject().addProperty("trap",trap);
        jsonParam.get("hinder").getAsJsonObject().addProperty("fire",fire);
        jsonParam.get("hinder").getAsJsonObject().addProperty("room",room);
        jsonParam.get("hinder").getAsJsonObject().addProperty("hole",hole);

        TILE_COLS=cols;
        TILE_ROWS=rows;
        TRAP_QTY =trap;
        FIRE_QTY =fire;
        ROOM_QTY =room;
        HOLE_QTY =hole;
        SaveFile();
    }
    /**
     * Save the parameters to a local file
     * */
    private void SaveFile()
    {
        try
        {
            // The path here has been manipulated a little, no better way has been found yet
            //String filepath=getClass().getResource("").toString().replace("file:/","")+CONFIGFILE;

            File file=new File(CONFIGFILE);

            // Configuration file does not exist Create first
            if (!file.exists())
            {
                file.createNewFile();
            }

            try (FileWriter writer = new FileWriter(file))
            {
                writer.write(jsonParam.toString());
                writer.flush();
            }
        }
        catch (Exception ex)
        {
            System.out.println("SaveFile->error:"+ex.getMessage());
        }
    }

    /**
     * Save ranking list data
     * */
    public void  SaveScoreList()
    {
        try
        {
            JsonArray  jarScoreList=new JsonArray();
            for (Score item :scoreList)
            {
                JsonObject jsonScore=new JsonObject();
                jsonScore.addProperty("player",item.player);
                jsonScore.addProperty("integral",item.integral);
                jsonScore.addProperty("wins",item.wins);
                jsonScore.addProperty("records",item.records);
                jsonScore.addProperty("cells",item.cells);
                jarScoreList.add(jsonScore);
            }
            jsonParam.add("scores",jarScoreList);
            SaveFile();
        }
        catch (Exception ex)
        {
            System.out.println("SaveScoreList->error:"+ex.getMessage());
        }
    }
}
