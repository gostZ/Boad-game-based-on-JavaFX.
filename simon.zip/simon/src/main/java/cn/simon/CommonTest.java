package cn.simon;

import cn.simon.model.Score;
import org.junit.Assert;
import org.junit.Test;

import static org.junit.Assert.*;

public class CommonTest
{

    @Test
    public void getPlayerName()
    {
        Common common=new Common();
        String playerName=common.getPlayerName("playera");
        System.out.println(playerName);
        //Assert.assertEquals("Jack",playerName);
        System.out.println("ok");
    }

    @Test
    public void setPlayerName()
    {
        Common common=new Common();
        String name="Divad";
        common.setPlayerName("playera",name);
        String playerName=common.getPlayerName("playera");
        Assert.assertEquals(name,playerName);
        System.out.println("ok");
    }

    @Test
    public void initGame()
    {
        Common common=new Common();
        Assert.assertNull(common.board);
        Assert.assertEquals(0,common.playerList.size());
        Assert.assertEquals(0,common.scoreList.size());
        common.InitGame();
        Assert.assertNotNull(common.board);
        Assert.assertEquals(2,common.playerList.size());
        System.out.println(common.playerList.get(0).name);
        //assertEquals("Jack", common.playerList.get(0).name);
        Assert.assertTrue(common.scoreList.size()>=0);
        System.out.println("ok");
    }

    @Test
    public void savePlayerName()
    {
        Common common=new Common();
        System.out.println("TILE_ROWS="+String.valueOf(common.TILE_ROWS));
        System.out.println("TILE_COLS="+String.valueOf(common.TILE_COLS));
        System.out.println("TRAP_QTY="+String.valueOf(common.TRAP_QTY));
        System.out.println("FIRE_QTY="+String.valueOf(common.FIRE_QTY));
        System.out.println("ROOM_QTY="+String.valueOf(common.ROOM_QTY));
        System.out.println("HOLE_QTY="+String.valueOf(common.HOLE_QTY));
        System.out.println("PlayerA="+common.getPlayerName("playera"));
        System.out.println("PlayerB="+common.getPlayerName("playerb"));

        common.SavePlayerName("Tom","Selina",6,10,1,2,1,2);

        Assert.assertEquals(10,common.TILE_ROWS);
        Assert.assertEquals(6,common.TILE_COLS);
        Assert.assertEquals(1,common.TRAP_QTY);
        Assert.assertEquals(2,common.FIRE_QTY);
        Assert.assertEquals(1,common.ROOM_QTY);
        Assert.assertEquals(2,common.HOLE_QTY);
        Assert.assertEquals("Tom",common.getPlayerName("playera"));
        Assert.assertEquals("Selina",common.getPlayerName("playerb"));

        System.out.println("ok");
    }

    @Test
    public void saveScoreList()
    {
        Common common=new Common();
        common.InitGame();
        String scoreStr="";
        for (Score item : common.scoreList)
        {
            scoreStr=
                "Player:"+item.player+", integral:"+String.valueOf(item.integral)+", wins:"+String.valueOf(item.wins)+", records:"+String.valueOf(item.records)+", cells:"+String.valueOf(item.cells);
            System.out.println(scoreStr);
        }

        System.out.println("--------------------------------------------");

        Score score=new Score();
        score.player="Isablab";
        score.wins=1;
        score.records=2;
        score.cells=40;
        score.grade();
        if (common.scoreList.indexOf(score)==-1)
            common.scoreList.add(score);

        common.SaveScoreList();
        common.InitGame();
        for (Score item : common.scoreList)
        {
            scoreStr=
                "Player:"+item.player+", integral:"+String.valueOf(item.integral)+", wins:"+String.valueOf(item.wins)+", records:"+String.valueOf(item.records)+", cells:"+String.valueOf(item.cells);
            System.out.println(scoreStr);
        }

        System.out.println("ok");
    }
}
