package cn.simon;

import cn.simon.control.GameBottom;
import cn.simon.control.GameCenter;
import cn.simon.control.GameLeft;
import cn.simon.control.GameTop;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Rectangle2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;

/**
 * Initial game interface
 * */
public class FrmGame extends Application
{
    private Stage gameStage=new Stage();

    public static Common common=new Common();

    public static GameTop    gameTop;
    public static GameLeft   gameLeft;
    public static GameCenter gameCenter;
    public static GameBottom gameBottom;

    private BorderPane borderPane;
    private Rectangle2D visiableScreen;

    @Override
    public void start(Stage stage) throws Exception
    {
        try
        {
            //Get the visible height and width of the screen
            CreateUIControl();

            Scene scene = new Scene(borderPane, visiableScreen.getWidth(), visiableScreen.getHeight());
            stage.setScene(scene);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Game Window");
            stage.setMaximized(true);
            stage.setScene(scene);
            stage.showAndWait();
        }
        catch (Exception ex)
        {
            System.out.println("start->error:"+ex.getMessage());
        }
    }

    public static void main(String[] args)
    {
        launch(args);
    }

    public void showwindow()
    {
        try
        {
            start(gameStage);
        }
        catch (Exception ex)
        {
            System.out.println("showwindow->error:"+ex.getMessage());
        }
    }

    private void CreateUIControl()
    {
        //Get the visible height and width of the screen
        visiableScreen = Screen.getPrimary().getVisualBounds();

        //Initialise data
        common.InitGame();

        borderPane = new BorderPane();
        gameTop = new GameTop();
        gameTop.setId("gameTop");
        gameLeft = new GameLeft();
        gameLeft.setId("gameLeft");
        gameBottom = new GameBottom();
        gameBottom.setId("gameBotton");

        /**
         * Here the centre width is calculated - 140 by filling the top
         * and bottom of GameTop height 40 + GameBotton height 80 + GameLeft by 10 + 10 each
         *
         * Calculation of centre height in some places - 260 is the column width in RecordVbox
         * and 250 + GameLeft's left and right padding of 5+5 each
         * */
        gameCenter = new GameCenter(visiableScreen.getHeight() - 140, visiableScreen.getWidth() - 260);
        gameCenter.setId("gameCenter");

        borderPane.setTop(gameTop);
        borderPane.setLeft(gameLeft);
        borderPane.setBottom(gameBottom);
        borderPane.setCenter(gameCenter);
        //Set gameCenter to take up the entire space
        BorderPane.setMargin(gameCenter, new Insets(0, 0, 0, 0));
    }

    public Parent getRoot()
    {
        CreateUIControl();
        return borderPane;
    }
}
