package cn.simon;

import cn.simon.control.ParamHBox;
import cn.simon.dialog.DialogAlter;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * Parameter configuration interface implementation class
 * */
public class FrmParam extends Application
{
    private Stage setStage=new Stage();
    private Common common;
    private VBox vBox;
    private Button btnSave;
    private HBox hBox;
    private String playerA,playerB;
    private ParamHBox hBoxA,hBoxB,hBoxTileCol,hBoxTileRow,hBoxTrap,hBoxRoom,hBoxFire,hBoxHole;

    @Override
    public void start(Stage stage) throws Exception
    {

        CreateUiControl();

        Scene scene=new Scene(vBox,350,480);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Setting Parameter");
        stage.setResizable(false);
        stage.setScene(scene);
        stage.showAndWait();
    }

    public static void main(String[] args)
    {
        launch(args);
    }

    public void showwindow()
    {
        try
        {
            start(setStage);
        }
        catch (Exception ex){}
    }

    private int StringToInt(String value)
    {
        int result=0;
        try
        {
            result=Integer.parseInt(value);
        }
        catch (Exception ex) {}

        return result;
    }

    private void CreateUiControl()
    {
        common=new Common();
        playerA=common.getPlayerName("playera");
        playerB=common.getPlayerName("playerb");

        vBox=new VBox();
        vBox.setSpacing(5);
        vBox.setPadding(new Insets(10,5,20,5));

        //Player A name setting
        hBoxA=new ParamHBox("PlayerA Name:", playerA);
        hBoxA.setId("hBoxA");
        vBox.getChildren().add(hBoxA);

        //Player B name setting
        hBoxB=new ParamHBox("PlayerB Name:", playerB);
        hBoxB.setId("hBoxB");
        vBox.getChildren().add(hBoxB);

        //Grid column and row settings
        hBoxTileCol=new ParamHBox("Game Tile Cols:", Integer.toString(FrmGame.common.TILE_COLS));
        hBoxTileCol.setId("hBoxTileCol");
        vBox.getChildren().add(hBoxTileCol);

        hBoxTileRow=new ParamHBox("Game Tile Rows:", Integer.toString(FrmGame.common.TILE_ROWS));
        hBoxTileRow.setId("hBoxTileRow");
        vBox.getChildren().add(hBoxTileRow);

        //Number of traps
        hBoxTrap=new ParamHBox("Hinder Trap Qty:", Integer.toString(FrmGame.common.TRAP_QTY));
        hBoxTrap.setId("hBoxTrap");
        vBox.getChildren().add(hBoxTrap);

        //Number of rooms
        hBoxRoom=new ParamHBox("Hinder Room Qty:", Integer.toString(FrmGame.common.ROOM_QTY));
        hBoxRoom.setId("hBoxRoom");
        vBox.getChildren().add(hBoxRoom);

        //Number of fires
        hBoxFire=new ParamHBox("Hinder Fire Qty:", Integer.toString(FrmGame.common.FIRE_QTY));
        hBoxFire.setId("hBoxFire");
        vBox.getChildren().add(hBoxFire);

        //Number of holes
        hBoxHole=new ParamHBox("Hinder Hole Qty:", Integer.toString(FrmGame.common.HOLE_QTY));
        hBoxHole.setId("hBoxHole");
        vBox.getChildren().add(hBoxHole);

        btnSave=new Button("Save Parameter");

        btnSave.setPrefWidth(200);
        btnSave.setPrefHeight(60);

        btnSave.setId("btnSave");

        btnSave.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent)
            {

                int cols=StringToInt(hBoxTileCol.getFieldValue());
                int rows=StringToInt(hBoxTileRow.getFieldValue());
                int trap=StringToInt(hBoxTrap.getFieldValue());
                int fire=StringToInt(hBoxFire.getFieldValue());
                int room=StringToInt(hBoxRoom.getFieldValue());
                int hole=StringToInt(hBoxHole.getFieldValue());
                if (cols<4)  cols=4;
                if (rows<8)  rows=8;
                common.SavePlayerName(hBoxA.getFieldValue(),hBoxB.getFieldValue(),cols,rows,trap,fire,room,hole);
                DialogAlter.show(" It's Ok! ");
            }
        });

        hBox=new HBox();
        hBox.getChildren().add(btnSave);
        hBox.setAlignment(Pos.BOTTOM_CENTER);
        hBox.setPrefHeight(200);

        hBox.setLayoutX(100);
        hBox.setLayoutY(100);

        vBox.getChildren().add(hBox);

    }

    public Parent getRoot()
    {
        CreateUiControl();
        return vBox;
    }

}
