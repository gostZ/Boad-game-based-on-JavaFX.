package cn.simon;

import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseButton;
import javafx.stage.Stage;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
//import org.loadui.testfx.GuiTest;
import org.testfx.api.FxToolkit;
import org.testfx.framework.junit.ApplicationTest;
import org.testfx.matcher.control.TextInputControlMatchers;

import static org.testfx.api.FxAssert.verifyThat;
import static org.testfx.matcher.control.LabeledMatchers.hasText;

import java.util.concurrent.TimeoutException;

public class FrmParamTest extends ApplicationTest
{

    @Before
    public void setUpClass() throws Exception {

        //ApplicationTest.launch(Main.class);
    }

    @After
    public void afterEachTest() throws TimeoutException
    {
        FxToolkit.hideStage();
        release(new KeyCode[]{});
        release(new MouseButton[]{});
    }

    public <T extends Node> T find(final String query) {
        return (T) lookup(query).queryAll().iterator().next();
    }

    @Override
    public void start(Stage stage)
    {
        try
        {
            Parent sceneRoot = (new FrmParam()).getRoot();
            Scene scene = new Scene(sceneRoot, 100, 100);
            stage.setScene(scene);
            stage.show();
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }

    @Test
    public void should_contain_button() {
        verifyThat("#btnSave", hasText("Save Parameter"));
    }

    @Test
    public void Should_contain_RowColLabel()
    {
        Label lbl=(Label) lookup("#hBoxTileCol").query().lookup("#lblname");
        verifyThat(lbl,hasText("Game Tile Cols:"));
        lbl=(Label) lookup("#hBoxTileRow").query().lookup("#lblname");
        verifyThat(lbl,hasText("Game Tile Rows:"));
    }

    @Test
    public void Should_contain_RowColTextField()
    {
        TextField txtField=(TextField) lookup("#hBoxTileCol").query().lookup("#txtvalue");
        verifyThat(txtField, TextInputControlMatchers.hasText("6"));
        txtField=(TextField) lookup("#hBoxTileRow").query().lookup("#txtvalue");
        verifyThat(txtField, TextInputControlMatchers.hasText("10"));
    }

    @Test
    public void Should_contain_PlayerLabel()
    {
        Label lbl=(Label) lookup("#hBoxA").query().lookup("#lblname");
        verifyThat(lbl,hasText("PlayerA Name:"));
        lbl=(Label) lookup("#hBoxB").query().lookup("#lblname");
        verifyThat(lbl,hasText("PlayerB Name:"));
    }

    @Test
    public void Should_contain_PlayerTextField()
    {
        TextField txtField=(TextField) lookup("#hBoxA").query().lookup("#txtvalue");
        verifyThat(txtField, TextInputControlMatchers.hasText("Jack"));
        txtField=(TextField) lookup("#hBoxB").query().lookup("#txtvalue");
        verifyThat(txtField, TextInputControlMatchers.hasText("Lisa"));
    }

    @Test
    public void Should_contain_HinderQtyLabel()
    {
        Label lbl=(Label) lookup("#hBoxTrap").query().lookup("#lblname");
        verifyThat(lbl,hasText("Hinder Trap Qty:"));

        lbl=(Label) lookup("#hBoxRoom").query().lookup("#lblname");
        verifyThat(lbl,hasText("Hinder Room Qty:"));

        lbl=(Label) lookup("#hBoxFire").query().lookup("#lblname");
        verifyThat(lbl,hasText("Hinder Fire Qty:"));

        lbl=(Label) lookup("#hBoxHole").query().lookup("#lblname");
        verifyThat(lbl,hasText("Hinder Hole Qty:"));

    }

    @Test
    public void Should_contain_HinderQtyTextField()
    {
        TextField txtField=(TextField) lookup("#hBoxTrap").query().lookup("#txtvalue");
        verifyThat(txtField, TextInputControlMatchers.hasText("1"));

        txtField=(TextField) lookup("#hBoxRoom").query().lookup("#txtvalue");
        verifyThat(txtField, TextInputControlMatchers.hasText("1"));

        txtField=(TextField) lookup("#hBoxFire").query().lookup("#txtvalue");
        verifyThat(txtField, TextInputControlMatchers.hasText("2"));

        txtField=(TextField) lookup("#hBoxHole").query().lookup("#txtvalue");
        verifyThat(txtField, TextInputControlMatchers.hasText("2"));

    }

}
