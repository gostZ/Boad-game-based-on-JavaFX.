package cn.simon;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application
{
    private VBox root;
    @Override
    public void start(Stage stage) throws Exception
    {
        CreateUIControl();


        Scene scene=new Scene(root,350,350);
        stage.setTitle("Simon's Race");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();

    }

    public static void main(String[] args)
    {
        launch(args);
    }

    private void CreateUIControl()
    {
        root=new VBox();

        Button btnInit=new Button("Parameter Setting");
        Button btnStart=new Button("Start Game");

        btnInit.setPrefWidth(200);
        btnInit.setPrefHeight(60);

        btnInit.setId("btnInit");

        btnStart.setPrefWidth(200);
        btnStart.setPrefHeight(60);

        btnStart.setId("btnStart");

        btnInit.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                FrmParam param=new FrmParam();
                param.showwindow();
            }
        });

        btnStart.setOnAction(actionEvent -> {
            FrmGame frmGame=new FrmGame();
            frmGame.showwindow();

        });

        root.setPadding(new Insets(80,20,20,75));
        root.setSpacing(40);
        root.getChildren().addAll(btnInit,btnStart);
    }

    public Parent getRoot()
    {
        CreateUIControl();
        return root;
    }

}
