package cn.simon;

import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.junit.Test;
import org.testfx.framework.junit.ApplicationTest;

import static org.junit.Assert.*;
import static org.testfx.api.FxAssert.verifyThat;
import static org.testfx.matcher.control.LabeledMatchers.hasText;

public class MainTest extends ApplicationTest
{

    @Override
    public void start(Stage stage)
    {
        try
        {
            Parent sceneRoot = (new Main()).getRoot();
            Scene scene = new Scene(sceneRoot, 100, 100);
            stage.setScene(scene);
            stage.show();
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }

    @Test
    public void should_contain_button()
    {
        verifyThat("#btnInit", hasText("Parameter Setting"));
        verifyThat("#btnStart", hasText("Start Game"));
    }


}
