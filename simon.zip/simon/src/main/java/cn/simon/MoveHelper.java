package cn.simon;

import cn.simon.model.MoveResult;
import cn.simon.model.Player;
import cn.simon.model.Point;
import cn.simon.model.Tile;

import java.util.ArrayList;


/**
 * Implementing a mobile position calculation class
 * */
public class MoveHelper
{
    /**
     * tileTop,tileBottom,tileLeft,tileRight: Storing the current player's grid data in four directions: up, down, left and right
     * curCol,curRow : Player's current location
     * moveResult : Storage of removable calculations
     * */

    //player
    private Player player;
    //steps number
    private int steps;
    //direct
    private int direct;
    private int curCol,curRow;
    private Tile tileTop,tileBottom,tileLeft,tileRight;
    private MoveResult moveResult=new MoveResult();


    /**
     * Constructor for the move position calculation class.
     * @param player Player Object
     * @param steps Number of squares to be moved
     * @param direct Direction of movement
     * */
    public MoveHelper(Player player,int steps,int direct)
    {
        this.player=player;
        this.steps=steps;
        this.direct=direct;
        curCol=player.col;
        curRow=player.row;
        moveResult.col=curCol;
        moveResult.row=curRow;
    }

    /**
     * Calculate the position to which the player can move.
     *
     * This method implements the player's movement, mainly
     * after the player encounters an obstacle (by calculating
     * the left and right obstacle conditions and determining
     * the player's forward direction after encountering an obstacle)
     *
     * @return Player moveable result data
     * */
    public MoveResult TryMove()
    {
        ///Number of frames that can be moved forward, left, right or backward
        int forwardStep,leftStep,rightStep,bottomStep;
        /// Temporary storage of mobile lines
        ArrayList<Point> moveline=new ArrayList<>();
        /// Record the number of squares moved this time
        int movesteps=0;
        try
        {
            // Direction of forward movement
            if (direct==1 || direct==2)
            {
                while (steps>0)
                {
                    forwardStep = CheckForward(curCol, curRow, steps);
                    if (moveResult.isOver)
                    {
                        return moveResult;
                    }

                    // Record the line moving upwards
                    for (int i=1;i<=forwardStep;++i)
                    {
                        moveline.add(new Point(curCol,curRow-i));
                    }

                    curRow = curRow - forwardStep;
                    // Number of targets remaining
                    steps = steps - forwardStep;

                    // Update the number of squares moved
                    movesteps=movesteps+forwardStep;

                    leftStep =CheckLeftUp(curCol,curRow,steps);
                    rightStep=CheckRightUp(curCol,curRow,steps);

                    //The first priority is to move up as much as possible and to determine which direction to move left or right
                    if ((leftStep==0 && rightStep>0) || (leftStep>0 && leftStep>rightStep && rightStep>0))
                    {
                        // Record the line moving to the right
                        for (int i=1;i<=rightStep;++i)
                        {
                            moveline.add(new Point(curCol+i,curRow));
                        }

                        // Move to the right
                        curCol=curCol+rightStep;
                        steps=steps-rightStep;
                        movesteps=movesteps+rightStep;
                    }
                    else if ((rightStep==0 && leftStep>0) || (rightStep>0 && rightStep>leftStep && leftStep>0))
                    {
                        // Record the line moving to the left
                        for (int i=1;i<=leftStep;++i)
                        {
                            moveline.add(new Point(curCol-i,curRow));
                        }
                        // Move to the left
                        curCol=curCol-leftStep;
                        steps=steps-leftStep;
                        movesteps=movesteps+leftStep;
                    }
                    else if (rightStep>0 && rightStep==leftStep)
                    {
                        // Left and right movements are the same, with priority given to movement towards the centre
                        if ( (FrmGame.common.TILE_COLS/2) < curCol)
                        {
                            for (int i=1;i<=leftStep;++i)
                            {
                                moveline.add(new Point(curCol-i,curRow));
                            }
                            curCol = curCol - leftStep;
                            steps=steps-leftStep;
                            movesteps=movesteps+leftStep;
                        }
                        else
                        {
                            for (int i=1;i<=rightStep;++i)
                            {
                                moveline.add(new Point(curCol+i,curRow));
                            }
                            curCol = curCol + rightStep;
                            steps=steps-rightStep;
                            movesteps=movesteps+rightStep;
                        }
                    }

                    //update position
                    moveResult.row = curRow;
                    moveResult.col = curCol;
                    moveResult.cells=movesteps;
                    moveResult.moveLines=moveline;

                    ///It means that the player has reached a dead end and has to wait for a chance to fall back
                    if ((forwardStep+leftStep+rightStep)==0)
                    {
                        break;
                    }

                    if (!player.isTrap)
                    {
                        tileTop = FrmGame.common.board[curCol][curRow];
                        if (tileTop.hasTrap())
                        {
                            // Current position is in a trap and is not moving
                            break;
                        }
                    }
                }
            }
            else if (direct==3)
            {
                while (steps>0) {

                    bottomStep = CheckDown(curCol, curRow, steps);

                    /// Players have started online
                    if (moveResult.row == FrmGame.common.TILE_ROWS) {
                        curRow = FrmGame.common.TILE_ROWS;
                        steps = 0;
                    } else {
                        curRow = curRow + bottomStep;
                        // Number of targets remaining
                        steps = steps - bottomStep;
                    }

                    movesteps = movesteps + bottomStep;

                    leftStep = CheckLeftDown(curCol, curRow, steps);
                    rightStep = CheckRightDown(curCol, curRow, steps);

                    //The direction of movement to the left and
                    // right is determined by the principle of moving down as little as possible.
                    if ((leftStep == 0 && rightStep > 0) || (leftStep > 0 && leftStep < rightStep)) {
                        // move to right
                        curCol = curCol + rightStep;
                        steps = steps - rightStep;
                        movesteps = movesteps + rightStep;
                    } else if ((rightStep == 0 && leftStep > 0) || (rightStep > 0 && rightStep < leftStep)) {
                        // move to left
                        curCol = curCol - leftStep;
                        steps = steps - leftStep;
                        movesteps = movesteps + leftStep;
                    } else if (rightStep > 0 && rightStep == leftStep) {
                        //Left and right movements are the same, with priority given to movement towards the centre
                        if ((FrmGame.common.TILE_COLS / 2) < curCol) {
                            curCol = curCol - leftStep;
                            steps = steps - leftStep;
                            movesteps = movesteps + leftStep;
                        } else {
                            curCol = curCol + rightStep;
                            steps = steps - rightStep;
                            movesteps = movesteps + rightStep;
                        }
                    }

                    // Update row position
                    moveResult.row = curRow;
                    moveResult.col = curCol;
                    moveResult.cells = movesteps;

                    ///It means that the player has reached a dead end and has to wait for a chance to move forward
                    if ((bottomStep + leftStep + rightStep) == 0) {
                        break;
                    }

                    if (!player.isTrap)
                    {
                        tileBottom = FrmGame.common.board[curCol][curRow];
                        if (tileBottom.hasTrap())
                        {
                            //Current position is in a trap and is not moving
                            break;
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            System.out.println("TryMove->error:"+ex.getMessage());
        }
        return moveResult;
    }


    /**
     * Calculate the number of squares that can be advanced in a given position.
     * @param col Number of columns in the player's current grid
     * @param row Number of rows in the player's current grid
     * @param count Number of moving target frames
     * @return Actual number of rows that can be moved
     * */
    private int CheckForward(int col,int row,int count)
    {
        int result=0;
        try
        {
            // Trapped end of advance sign
            boolean isTrap=false;

            // Judging obstacles in the direction of travel
            for (int i = 1; i < count + 1; ++i)
            {
                if ((row-i)< 0)
                {
                    moveResult.col = col;
                    moveResult.row = 0;
                    moveResult.isOver = true;
                    break;
                }

                // Get the data in the forward direction grid
                tileTop = FrmGame.common.board[col][row-i];
                // Obstacles in the direction of travel
                if (tileTop.hasObject())
                {
                    break;
                }
                else
                {
                    // Player not previously in the trap
                    if (!player.isTrap)
                    {
                        if (tileTop.hasTrap())
                        {
                            isTrap = true;
                        }
                        else if (isTrap)
                        {
                            // The upper boundary of the trap is reached
                            break;
                        }
                    }

                    result =i;
                    continue;
                }
            }
        }
        catch (Exception ex)
        {
            System.out.println("CheckForward->error:"+ex.getMessage());
        }
        return result;
    }

    /**
     * Calculate the number of squares that can be shifted to the left of the specified position
     * @param col Number of columns in the player's current grid
     * @param row Number of rows in the player's current grid
     * @param count Number of rows in the player's current grid
     * @return Actual number of columns that can be moved
     * */
    private int CheckLeftUp(int col,int row,int count)
    {
        int result=0;
        try
        {

            // Access to the trap sign
            boolean isTrap=false;

            // Determining the condition of obstacles to the left
            for (int i = 1; i < count + 1; ++i)
            {
                // Already on the far left
                if ((col-i)<0)
                {
                    break;
                }
                // Get the data in the left shift direction cell
                tileLeft = FrmGame.common.board[col-i][row];
                // Obstacle in the direction of the left shift
                if (tileLeft.hasObject())
                {
                    break;
                }
                else
                {
                    if (!player.isTrap)
                    {
                        if (tileLeft.hasTrap())
                        {
                            isTrap = true;
                        }
                        else if (isTrap)
                        {
                            // The left boundary of the trap has been reached
                            break;
                        }
                    }

                    result =i;
                    // Get the data of the left move and then forward direction grid
                    tileTop=FrmGame.common.board[col-i][row-1];
                    if (tileTop.hasObject())
                        continue;
                    else
                        break;
                }
            }
        }
        catch (Exception ex)
        {
            System.out.println("CheckLeftUp->error:"+ex.getMessage());
        }
        return result;
    }

    /**
     * Calculate the number of frames that can be shifted to the right at a given position
     * @param col Number of columns in the player's current grid
     * @param row Number of rows in the player's current grid
     * @param count Number of moving target frames
     * @return Actual number of columns that can be moved
     * */
    private int CheckRightUp(int col,int row,int count)
    {
        int result=0;
        try
        {
            boolean isTrap=false;

            // Determining the condition of obstacles to the right
            for (int i = 1; i < count + 1; ++i)
            {
                // Already on the far right
                if ((col+i)>FrmGame.common.TILE_COLS-1)
                {
                    break;
                }
                // Get the data in the right shift cell
                tileRight = FrmGame.common.board[col+i][row];
                // Obstacle in the direction of the left shift
                if (tileRight.hasObject())
                {
                    break;
                }
                else
                {
                    if (!player.isTrap)
                    {
                        if (tileRight.hasTrap())
                        {
                            isTrap = true;
                        }
                        else if (isTrap)
                        {
                            // The right boundary of the trap has been reached
                            break;
                        }
                    }

                    result =i;
                    // Get the data of the grid in the direction of advance after moving right
                    tileTop=FrmGame.common.board[col+i][row-1];
                    if (tileTop.hasObject())
                        continue;
                    else
                        break;
                }
            }
        }
        catch (Exception ex)
        {
            System.out.println("CheckRightUp->error:"+ex.getMessage());
        }
        return result;
    }

    /**
     * Calculate the number of frames that can be shifted down to the specified position
     * @param col Number of columns in the player's current grid
     * @param row Number of rows in the player's current grid
     * @param count Number of moving target frames
     * @return Actual number of rows that can be moved
     * */
    private int CheckDown(int col,int row,int count)
    {
        int result=0;
        try
        {
            boolean isTrap=false;

            // Determining obstacle conditions in the direction of retreat
            for (int i = 1; i < count + 1; ++i)
            {
                // Back to the starting line
                if ((row+i)>FrmGame.common.TILE_ROWS-1)
                {
                    moveResult.row=FrmGame.common.TILE_ROWS;
                    moveResult.col=col;
                    break;
                }

                // Get the data in the backward direction grid
                tileBottom = FrmGame.common.board[col][row+i];
                // Obstacles in the direction of retreat
                if (tileBottom.hasObject())
                {
                    break;
                }
                else
                {
                    if (!player.isTrap)
                    {
                        if (tileBottom.hasTrap())
                        {
                            isTrap = true;
                        }
                        else if (isTrap)
                        {
                            //The left boundary of the trap has been reached
                            break;
                        }
                    }

                    result =i;
                    continue;
                }
            }
        }
        catch (Exception ex)
        {
            System.out.println("CheckDown->error:"+ex.getMessage());
        }
        return result;
    }

    /**
     * Calculate the number of squares that can be shifted to the left at a given position.
     * @param col Number of columns in the player's current grid
     * @param row Number of rows in the player's current grid
     * @param count Number of moving target frames
     * @return Actual number of rows that can be moved
     * */
    private int CheckLeftDown(int col,int row,int count)
    {
        int result=0;
        try
        {
            boolean isTrap=false;

            // Determining the condition of obstacles to the left
            for (int i = 1; i < count + 1; ++i)
            {
                // Already on the far left
                if ((col-1)<0)
                {
                    break;
                }

                // Get the data in the left shift direction cell
                tileLeft = FrmGame.common.board[col-i][row];
                // Obstacle in the direction of the left shift
                if (tileLeft.hasObject())
                {
                    break;
                }
                else
                {
                    if ((row+1)<FrmGame.common.TILE_ROWS-1)
                    {
                        if (!player.isTrap)
                        {
                            if (tileLeft.hasTrap())
                            {
                                isTrap = true;
                            }
                            else if (isTrap)
                            {
                                // The left boundary of the trap has been reached
                                break;
                            }
                        }

                        result = i;
                        // Get left shift then backward grid data
                        tileTop = FrmGame.common.board[col - i][row + 1];
                        if (tileTop.hasObject())
                            continue;
                        else
                            break;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            System.out.println("CheckLeftDown->error:"+ex.getMessage());
        }
        return result;
    }

    /**
     * Calculate the number of frames that can be shifted to the right at a given position.
     * @param col Number of columns in the player's current grid
     * @param row Number of rows in the player's current grid
     * @param count Number of moving target frames
     * @return Actual number of rows that can be moved
     * */
    private int CheckRightDown(int col,int row,int count)
    {
        int result=0;
        try
        {
            boolean isTrap=false;

            // Determining the condition of obstacles to the right
            for (int i = 1; i < count + 1; ++i)
            {
                // Already on the far right
                if ((col+i)>FrmGame.common.TILE_COLS-1)
                {
                    break;
                }
                // Get the data in the right shift cell
                tileRight = FrmGame.common.board[col+i][row];
                // Obstacle in the direction of the left shift
                if (tileRight.hasObject())
                {
                    break;
                }
                else
                {
                    if ((row+1)<FrmGame.common.TILE_ROWS-1)
                    {
                        if (!player.isTrap)
                        {
                            if (tileRight.hasTrap())
                            {
                                isTrap = true;
                            }
                            else if (isTrap)
                            {
                                // The right boundary of the trap has been reached
                                break;
                            }
                        }

                        result = i;
                        //  Get the data of the grid in the direction of the right move and then the backward move
                        tileTop = FrmGame.common.board[col + i][row + 1];
                        if (tileTop.hasObject())
                            continue;
                        else
                            break;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            System.out.println("CheckRightDown->error:"+ex.getMessage());
        }
        return result;
    }

}
