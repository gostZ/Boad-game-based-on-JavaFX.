package cn.simon;

import cn.simon.model.Hinder;
import cn.simon.model.MoveResult;
import cn.simon.model.Player;
import cn.simon.model.Tile;
import org.junit.Assert;
import org.junit.Test;

public class MoveHelperTest
{
    @Test
    public void tryMove()
    {
        Player      player;
        MoveHelper  moveHelper;
        MoveResult  result;
        Hinder      hinder;

        FrmGame.common.InitGame();

        FrmGame.common.TILE_ROWS=8;
        FrmGame.common.TILE_COLS=4;


        //Initialize the game grid
        for (int row = 0; row < FrmGame.common.TILE_ROWS; row++)
        {
            for (int col = 0; col < FrmGame.common.TILE_COLS; col++)
            {
                //Determine if it is an even number
                Tile tile = new Tile((col + row) % 2 == 0, col, row, 60,60);
                FrmGame.common.board[col][row] = tile;
            }
        }

        //Set the player's initial position in 1 column and 8 rows
        player=new Player("Lisa",1,FrmGame.common.TILE_ROWS,"playera");
        //Players move forward 3 steps
        moveHelper=new MoveHelper(player,3,2);
        result=moveHelper.TryMove();
        //Players need to move to 1 column and 5 rows
        Assert.assertEquals(1,result.col);
        Assert.assertEquals(5,result.row);

        //Set the player's current position in 1 column and 5 rows
        player=new Player("Lisa",1,5,"playera");
        //The player takes 1 step backwards
        moveHelper=new MoveHelper(player,1,3);
        result=moveHelper.TryMove();
        //Players need to move to 1 column and 6 rows
        Assert.assertEquals(1,result.col);
        Assert.assertEquals(6,result.row);

        //Set the player's current position in 1 column and 5 rows
        player=new Player("Lisa",1,6,"playera");
        //Players do not move in 3 steps
        moveHelper=new MoveHelper(player,3,4);
        result=moveHelper.TryMove();
        //Players remain in 1 column and 6 rows
        Assert.assertEquals(1,result.col);
        Assert.assertEquals(6,result.row);

        //Set obstacles in 1 column and 6 rows
        hinder = new Hinder("hole", 1, 6, 1,1);
        FrmGame.common.board[1][6].setObject(hinder, true);

        //Set the player's initial position in 1 column and 8 rows
        player=new Player("Lisa",1,FrmGame.common.TILE_ROWS,"playera");
        //Players move forward 3 steps
        moveHelper=new MoveHelper(player,3,2);
        result=moveHelper.TryMove();
        //Players need to move to 2 columns and 6 rows
        Assert.assertEquals(2,result.col);
        Assert.assertEquals(6,result.row);

        //Set the player's initial position in 1 column and 8 rows
        player=new Player("Lisa",1,7,"playera");
        //Players move forward 3 steps
        moveHelper=new MoveHelper(player,3,2);
        result=moveHelper.TryMove();
        //Players need to move to 2 columns and 5 rows
        Assert.assertEquals(2,result.col);
        Assert.assertEquals(5,result.row);

        System.out.println("ok");
    }
}
