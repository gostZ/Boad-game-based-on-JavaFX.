package cn.simon;

import cn.simon.dialog.DialogAlter;
import cn.simon.model.*;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.util.Duration;

import java.util.Comparator;
import java.util.Random;

/**
 * Player button event response class
 * */
public class PlayerEventHandler implements EventHandler<ActionEvent>
{
    private String playername;

    /**
     * SPECIALNOTURN : The number of times a player needs to take a turn to trigger a special trap
     * */
    private final int SPECIALNOTURN=3;


    /**
     * Player event response class constructor.
     * @param name player name
     * */
    public PlayerEventHandler(String name)
    {
        this.playername=name;
    }

    @Override
    public void handle(ActionEvent event)
    {
        try
        {
            // Generate movement points
            int dice    =PlayerThrow();
            // Generate direction of movement
            int direct  =PlayerThrow();

            if (playername.equals(FrmGame.common.playerList.get(0).name))
            {
                FrmGame.gameLeft.playerA.setDice(String.valueOf(dice));
                FrmGame.gameLeft.playerA.setDirection(DirectToEnum(direct).toString());

                // The player is in a trap and starts to trigger the turn rule
                if (FrmGame.common.playerList.get(0).isTrap && FrmGame.common.playerList.get(0).noTurn>0)
                {
                    FrmGame.common.playerList.get(0).noTurn-=1;
                    return;
                }

                // Direction is not immovable
                if (direct!=4)
                {
                    MoveHelper moveHelper=new MoveHelper(FrmGame.common.playerList.get(0),dice,direct);

                    MoveResult moveResult=moveHelper.TryMove();
                    if (moveResult.isOver)
                    {
                        FrmGame.gameCenter.MovePlayer(playername, moveResult.col,moveResult.row);
                        PlayerWins(playername);
                    }
                    else
                    {
                        /* Here the player moves from frame to frame, but the page does not reflect it

                        Timeline timeline = new Timeline();
                        timeline.getKeyFrames().add(new KeyFrame(Duration.millis(500),
                                e ->{
                                    Point pt;
                                    for (int i=0;i<moveResult.moveLines.size();++i)
                                    {
                                        pt=moveResult.moveLines.get(i);
                                        System.out.println("x="+String.valueOf(pt.getX())+"--y="+String.valueOf(pt.getY()));
                                        FrmGame.gameCenter.MovePlayer(playername,pt.getX(),pt.getY());
                                    }
                        }));
                        timeline.setCycleCount(moveResult.moveLines.size());
                        timeline.play();
                        */

                        FrmGame.gameCenter.MovePlayer(playername, moveResult.col, moveResult.row);

                        int oldcol=FrmGame.common.playerList.get(0).col;
                        int oldrow=FrmGame.common.playerList.get(0).row;

                        // Players are not at the starting point
                        if (oldrow<FrmGame.common.TILE_ROWS)
                        {
                            // Clear the player's data in the current grid
                            FrmGame.common.board[oldcol][oldrow].setObject(null,false);
                        }

                        FrmGame.common.playerList.get(0).col=moveResult.col;
                        FrmGame.common.playerList.get(0).row=moveResult.row;
                        FrmGame.common.playerList.get(0).cells=FrmGame.common.playerList.get(0).cells+moveResult.cells;

                        // Is the player's new position in a trap
                        if (moveResult.row<FrmGame.common.TILE_ROWS && FrmGame.common.board[moveResult.col][moveResult.row].hasTrap())
                        {
                            if (!FrmGame.common.playerList.get(0).isTrap) {
                                FrmGame.common.playerList.get(0).isTrap = true;
                                //Set the player to take a short turn after entering the trap
                                FrmGame.common.playerList.get(0).noTurn = SPECIALNOTURN;
                            }
                        }
                        else
                        {
                            FrmGame.common.playerList.get(0).isTrap = false;
                        }

                        // Save player data in a new grid
                        if (moveResult.row<FrmGame.common.TILE_ROWS)
                        {
                            FrmGame.common.board[moveResult.col][moveResult.row].setObject(FrmGame.common.playerList.get(0), false);
                        }
                    }
                }
            }

            if (playername.equals(FrmGame.common.playerList.get(1).name))
            {
                FrmGame.gameLeft.playerB.setDice(String.valueOf(dice));
                FrmGame.gameLeft.playerB.setDirection(DirectToEnum(direct).toString());

                // The player is in a trap and starts to trigger the turn rule
                if (FrmGame.common.playerList.get(1).isTrap && FrmGame.common.playerList.get(1).noTurn>0)
                {
                    FrmGame.common.playerList.get(1).noTurn-=1;
                    return;
                }

                if (direct!=4)
                {
                    MoveHelper moveHelper=new MoveHelper(FrmGame.common.playerList.get(1),dice,direct);

                    MoveResult moveResult=moveHelper.TryMove();
                    if (moveResult.isOver)
                    {
                        FrmGame.gameCenter.MovePlayer(playername, moveResult.col,moveResult.row);
                        PlayerWins(playername);
                    }
                    else
                    {
                        FrmGame.gameCenter.MovePlayer(playername, moveResult.col, moveResult.row);

                        int oldcol=FrmGame.common.playerList.get(1).col;
                        int oldrow=FrmGame.common.playerList.get(1).row;

                        // Players are not at the starting point
                        if (oldrow<FrmGame.common.TILE_ROWS)
                        {
                            // Clear the player's data in the current grid
                            FrmGame.common.board[oldcol][oldrow].setObject(null,false);
                        }

                        FrmGame.common.playerList.get(1).col=moveResult.col;
                        FrmGame.common.playerList.get(1).row=moveResult.row;
                        FrmGame.common.playerList.get(1).cells=FrmGame.common.playerList.get(1).cells+moveResult.cells;

                        // Determine if the player's new position is in a trap
                        if (moveResult.row<FrmGame.common.TILE_ROWS && FrmGame.common.board[moveResult.col][moveResult.row].hasTrap())
                        {
                            // Determining if you have just entered a trap
                            if (!FrmGame.common.playerList.get(1).isTrap)
                            {
                                FrmGame.common.playerList.get(1).isTrap = true;
                                // Set the player to take a short turn after entering the trap
                                FrmGame.common.playerList.get(1).noTurn = SPECIALNOTURN;
                            }
                        }
                        else
                        {
                            // Player not in a trap
                            FrmGame.common.playerList.get(1).isTrap=false;
                        }

                        // Save player data in a new grid
                        if (moveResult.row<FrmGame.common.TILE_ROWS)
                        {
                            FrmGame.common.board[moveResult.col][moveResult.row].setObject(FrmGame.common.playerList.get(1), false);
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            System.out.println("handle->error:"+ex.getMessage());
        }
    }

    /**
     * Simulates a player rolling a cork to generate a random number in the range [1,4].
     * @return Return the number of points rolled
     * */
    private int PlayerThrow()
    {
        Random random=new Random();
        return random.nextInt(4)+1;
    }

    /**
     * Directional values converted to enumerations for interface display
     * */
    private Direct DirectToEnum(int value)
    {
        if (value==1 || value==2)
            return Direct.Forward;
        else if (value==3)
            return Direct.Recede;
        else
            return Direct.NoTurn;
    }

    /**
     * The player wins the match and saves the data and initialises the game.
     * @param playername player name
     * */
    private void PlayerWins(String playername)
    {
        int movecells=0;
        Score score=null;
        try
        {
            DialogAlter.show(playername + " is Wins \n\n  Game is Over ");

            // Save data and set initial state
            if (playername.equals(FrmGame.common.playerList.get(0).name))
            {
                FrmGame.common.playerList.get(0).wins += 1;
            }

            if (playername.equals(FrmGame.common.playerList.get(1).name))
            {
                FrmGame.common.playerList.get(1).wins += 1;
            }

            FrmGame.common.playerList.get(0).records += 1;
            FrmGame.common.playerList.get(1).records += 1;

            // Updated leaderboard data
            int pos = -1;
            for (int i = 0; i < FrmGame.common.scoreList.size(); ++i)
            {
                if (FrmGame.common.scoreList.get(i).player.equals(FrmGame.common.playerList.get(0).name))
                {
                    score = FrmGame.common.scoreList.get(i);
                    pos = i;
                    break;
                }
            }

            movecells=FrmGame.common.playerList.get(0).cells;
            if (score == null)
            {
                score = new Score();
                score.player = FrmGame.common.playerList.get(0).name;
                if (FrmGame.common.playerList.get(0).name.equals(playername))
                    score.wins = 1;

                score.records = 1;
                score.cells =movecells;
                score.grade();
                FrmGame.common.scoreList.add(score);
            }
            else
            {
                if (FrmGame.common.playerList.get(0).name.equals(playername))
                    score.wins += 1;

                score.records += 1;
                score.cells += movecells;
                score.grade();
                FrmGame.common.scoreList.set(pos, score);
            }

            pos = -1;
            score=null;
            for (int i = 0; i < FrmGame.common.scoreList.size(); ++i)
            {
                if (FrmGame.common.scoreList.get(i).player.equals(FrmGame.common.playerList.get(1).name))
                {
                    score = FrmGame.common.scoreList.get(i);
                    pos = i;
                    break;
                }
            }

            movecells=FrmGame.common.playerList.get(1).cells;
            if (score == null)
            {
                score = new Score();
                score.player = FrmGame.common.playerList.get(1).name;
                if (FrmGame.common.playerList.get(1).name.equals(playername))
                    score.wins = 1;

                score.records = 1;
                score.cells = movecells;
                score.grade();
                FrmGame.common.scoreList.add(score);
            }
            else
            {
                if (FrmGame.common.playerList.get(1).name.equals(playername))
                    score.wins += 1;

                score.records += 1;
                score.cells += movecells;
                score.grade();
                FrmGame.common.scoreList.set(pos, score);
            }

            // Update player data to the start of a new game
            if (FrmGame.common.playerList.get(0).row!=FrmGame.common.TILE_ROWS)
            {
                // Clear the corresponding grid storage object
                FrmGame.common.board[FrmGame.common.playerList.get(0).col][FrmGame.common.playerList.get(0).row].setObject(null,false);
            }
            FrmGame.common.playerList.get(0).col=FrmGame.common.TILE_COLS/4;
            FrmGame.common.playerList.get(0).row=FrmGame.common.TILE_ROWS;
            FrmGame.gameCenter.MovePlayer(FrmGame.common.playerList.get(0).name,FrmGame.common.TILE_COLS/4,FrmGame.common.TILE_ROWS);

            if (FrmGame.common.playerList.get(1).row!=FrmGame.common.TILE_ROWS)
            {
                // Clear the corresponding grid storage object
                FrmGame.common.board[FrmGame.common.playerList.get(1).col][FrmGame.common.playerList.get(1).row].setObject(null,false);
            }
            FrmGame.common.playerList.get(1).col=3*FrmGame.common.TILE_COLS/4-1;
            FrmGame.common.playerList.get(1).row=FrmGame.common.TILE_ROWS;
            FrmGame.gameCenter.MovePlayer(FrmGame.common.playerList.get(1).name,3*FrmGame.common.TILE_COLS/4-1,
                                          FrmGame.common.TILE_ROWS);

            FrmGame.gameLeft.playerA.setDice("");
            FrmGame.gameLeft.playerA.setDirection("");

            FrmGame.gameLeft.playerB.setDice("");
            FrmGame.gameLeft.playerB.setDirection("");

            // Store leaderboards to local files
            FrmGame.common.SaveScoreList();
            // Refresh leaderboard list
            FrmGame.common.scoreList.sort(Comparator.reverseOrder());
            FrmGame.gameLeft.recordVBox.RefreshTable();
        }
        catch (Exception ex)
        {
            System.out.println("PlayerWins->error:"+ex.getMessage());
        }
    }


}
