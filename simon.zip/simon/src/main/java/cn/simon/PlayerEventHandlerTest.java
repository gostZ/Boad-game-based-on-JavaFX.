package cn.simon;

import static org.junit.Assert.*;

public class PlayerEventHandlerTest {

    @org.junit.Test
    public void handle() {
    }
}