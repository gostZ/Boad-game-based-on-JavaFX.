1. environment
version of IDEA : IntelliJ IDEA 2022.2.4 (Ultimate Edition)
Runtime version: 17.0.5+7-b469.71 aarch64
VM: OpenJDK 64-Bit Server VM by JetBrains s.r.o.
JDK version: zulu-17 Azul Zulu version 17.0.5
javafx version : aarch64 - 17.0.2

2.image path
To load image in game interface, the paths of images need to be change,
in java file called GameCenter in package "control":
1) in 108 line: change"/Users/zws/IdeaProjects/simon/src/main/resources/image/"+hinder.name+".png"
    to "path of this simon project in your computer + /simon/src/main/resources/image/"+hinder.name+".png"

2) in 149 line: change /Users/zws/IdeaProjects/simon/src/main/resources/image/"+imgname+".png
    to "path of this simon project in your computer + /simon/src/main/resources/image/"+imgname+".png"

3) in 184 line: change /Users/zws/IdeaProjects/simon/src/main/resources/image/"+player.imghead+".png
      to "path of this simon project in your computer + /simon/src/main/resources/image/"+player.imghead+".png"

3. junit test
 1）Before running each test, the "module-info.java" need to be deleted or rename this file

 2）If you have set the game parameters after running the game, please overwrite the original data in config （use the data below）.json with the following. This is because some tests need to test whether the game can retrieve player information from config.json, but if the contents of config.json have been modified, this will result in an incorrect answer.

{"users":{"playera":"Jack","playerb":"Lisa"},"tile":{"cols":6,"rows":10},"hinder":{"trap":1,"fire":2,"room":1,"hole":2},"scores":[{"player":"Tom","integral":142,"wins":1,"records":1,"cells":7},{"player":"Jack","integral":42,"wins":4,"records":7,"cells":95},{"player":"Lisa","integral":28,"wins":3,"records":7,"cells":107}]}