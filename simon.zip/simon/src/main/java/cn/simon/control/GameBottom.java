package cn.simon.control;

import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;

public class GameBottom extends AnchorPane
{
    public GameBottom()
    {
        this.setStyle("-fx-background-color: #4373c6");
        HBox hBox=new HBox();
        hBox.setId("hBox");
        hBox.setPrefHeight(80);
        this.getChildren().add(hBox);

    }
}
