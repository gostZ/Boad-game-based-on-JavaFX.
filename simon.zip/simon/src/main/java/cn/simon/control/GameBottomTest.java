package cn.simon.control;

import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import org.junit.Assert;
import org.junit.Test;
import org.testfx.framework.junit.ApplicationTest;

import static org.junit.Assert.*;

public class GameBottomTest extends ApplicationTest
{
    Parent sceneRoot;
    @Override
    public void start(Stage stage)
    {
        try
        {
            sceneRoot =new  ParamHBox("Player Name:","");
            Scene scene = new Scene(sceneRoot, 200, 80);
            stage.setScene(scene);
            stage.show();
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }

    @Test
    public void should_contain_HBox()
    {
        Assert.assertNotNull("#hBox");
    }

}
