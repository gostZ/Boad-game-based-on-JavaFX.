package cn.simon.control;

import cn.simon.FrmGame;
import cn.simon.model.Hinder;
import cn.simon.model.Player;
import cn.simon.model.Tile;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class GameCenter extends Pane
{
    /**
     * TileHeight : Height of each compartment
     * TileWidth : width of each compartment
     * hinderList : Record a list of placed obstacle positions
     * colList : Record the columns in which the obstacles have been placed and try to spread them over all columns
     * */
    private final Group tileGroup = new Group();
    public final ImageView imgPlayerA;
    private final ImageView imgPlayerB;

    private int TileHeight = 0;
    private int TileWidth = 0;
    private ImageView imgView_4;
    private List<String> hinderList = new ArrayList<>();
    private List<String> colList=new ArrayList<>();

    /**
     * Create game screen
     * */
    public GameCenter(double centerHeight, double centerWidth)
    {
        //Calculate the width and height of each grid
        TileHeight = (int) centerHeight / FrmGame.common.TILE_ROWS;
        TileWidth  = (int) centerWidth / FrmGame.common.TILE_COLS;

        //this.setStyle("-fx-background-color: green");

        Parent pane = CreateTile();
        pane.setId("tilePane");

        this.getChildren().add(pane);

        if (FrmGame.common.TRAP_QTY>0)
        {
            SetHinder("", FrmGame.common.TRAP_QTY, 1, 2, true);
        }
        if (FrmGame.common.FIRE_QTY>0)
        {
            SetHinder("fire", FrmGame.common.FIRE_QTY, 1, 2, false);
        }
        if (FrmGame.common.ROOM_QTY>0)
        {
            SetHinder("room", FrmGame.common.ROOM_QTY, 1, 2, true);
        }
        if (FrmGame.common.HOLE_QTY>0)
        {
            SetHinder("hole", FrmGame.common.HOLE_QTY, 1, 1, false);
        }
        imgPlayerA = CreatePlayer(FrmGame.common.playerList.get(0));
        this.getChildren().add(imgPlayerA);
        imgPlayerB = CreatePlayer(FrmGame.common.playerList.get(1));
        this.getChildren().add(imgPlayerB);

    }

    /**
     * Create a grid in the game.
     * */
    private Parent CreateTile()
    {
        AnchorPane root = new AnchorPane();
        root.setPrefSize(FrmGame.common.TILE_COLS * TileWidth, FrmGame.common.TILE_ROWS * TileHeight);
        root.getChildren().addAll(tileGroup);

        //Create a game desktop background
        for (int row = 0; row < FrmGame.common.TILE_ROWS; row++)
        {
            for (int col = 0; col < FrmGame.common.TILE_COLS; col++)
            {
                //Determine if it is an even number
                Tile tile = new Tile((col + row) % 2 == 0, col, row, TileWidth, TileHeight);
                FrmGame.common.board[col][row] = tile;
                tileGroup.getChildren().add(tile);
            }
        }
        return root;
    }


    /**
     * Create in-game obstacles in the grid.
     * @param hinder Obstacle objects
     * */
    private ImageView CreateHinder(Hinder hinder)
    {
        ImageView imageView = new ImageView();
        try
        {
            //Modify the path to the image here
            File f = new File("/Users/zws/IdeaProjects/simon/src/main/resources/image/"+hinder.name+".png");
            String url = f.toURI().toString();
            Image image = new Image(url);
            imageView = new ImageView(image);
            imageView.setFitWidth(hinder.spancol * TileWidth);
            imageView.setFitHeight(hinder.spanrow * TileHeight);
            imageView.relocate(hinder.col * TileWidth, hinder.row * TileHeight);
            //Bind the obstacle object to the corresponding grid
            for (int cl = 0; cl < hinder.spancol; ++cl)
            {
                for (int rw = 0; rw < hinder.spanrow; ++rw)
                {
                    FrmGame.common.board[hinder.col + cl][hinder.row + rw].setObject(hinder, true);
                }
            }
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }
        return imageView;
    }


    /**
     * Create special traps in the grid.
     * @param imgname Special trap image name (a "" means a hidden special trap is generated)
     * @param col Corresponding columns in the grid
     * @param row The corresponding row in the grid
     * @param spancol Number of columns accounted for by traps
     * @param spanrow Number of lines occupied by traps
     * */
    private void CreateTrap(String imgname, int col, int row, int spancol, int spanrow)
    {
        try
        {
            //The pictures are shown here for easy test observation
            if (!imgname.isBlank())
            {
                ImageView imageView = new ImageView();
                //Modify the path to the image here
                File f = new File("/Users/zws/IdeaProjects/simon/src/main/resources/image/"+imgname+".png");
                String url = f.toURI().toString();
                Image image = new Image(url);
                imageView = new ImageView(image);
                imageView.setFitWidth(spancol * TileWidth);
                imageView.setFitHeight(spanrow * TileHeight);
                imageView.relocate(col * TileWidth, row * TileHeight);
                this.getChildren().add(imageView);
            }

            for (int cl = 0; cl < spancol; ++cl)
            {
                for (int rw = 0; rw < spanrow; ++rw)
                {
                    FrmGame.common.board[col + cl][row + rw].setTrap(true);
                }
            }
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }


    /**
     * Create players in the grid
     * @param player Player Target
     * */
    private ImageView CreatePlayer(Player player)
    {
        ImageView imageView = new ImageView();
        try
        {
            //Modify the path to the image here
            File f = new File("/Users/zws/IdeaProjects/simon/src/main/resources/image/"+player.imghead+".png");
            String url = f.toURI().toString();
            Image image = new Image(url);
            imageView = new ImageView(image);
            imageView.setFitWidth(60);
            imageView.setFitHeight(60);
            imageView.relocate(player.col * TileWidth + (TileWidth - 60) / 2, player.row * TileHeight + (TileHeight - 60) / 2);
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }
        return imageView;
    }


    /**
     * Move player position.
     * @param player Player Target
     * @param col New column position
     * @param row New row position
     * */

    public void MovePlayer(String player, int col, int row)
    {
        //First player to move
        if (player.equals(FrmGame.common.playerList.get(0).name))
        {
            imgPlayerA.relocate(col * TileWidth + (TileWidth - 60) / 2, row * TileHeight + (TileHeight - 60) / 2);
        }
        //Second player moves
        if (player.equals(FrmGame.common.playerList.get(1).name))
        {
            imgPlayerB.relocate(col * TileWidth + (TileWidth - 60) / 2, row * TileHeight + (TileHeight - 60) / 2);
        }
    }


    /**
     * Dynamic setting of obstacle positions.
     * @param name Name of the obstacle (also the name of the picture)
     * @param qty number
     * @param spancol Number of columns occupied
     * @param spanrow Number of rows occupied
     * @param istrap It is a special obstacle
     * */
    public void SetHinder(String name, int qty, int spancol, int spanrow, boolean istrap)
    {
        try
        {
            Random random = new Random();
            int col = 0, row = 0, count = 0, loops = 0,lastcol=0,lastrow=0;
            String cr = "";
            boolean isused = false;
            for (int i = 0; i < qty; ++i)
            {
                count = 0;
                loops = FrmGame.common.TILE_COLS * (FrmGame.common.TILE_ROWS - 2);
                while (count < loops)
                {
                    ++count;

                    //Generate a random position
                    col = random.nextInt(FrmGame.common.TILE_COLS);
                    cr="-"+String.valueOf(col)+"-";
                    if (colList.indexOf(cr)!=-1)
                    {
                        for (int c = 0; c < FrmGame.common.TILE_COLS; ++c)
                        {
                            cr = "-"+String.valueOf(c)+"-";
                            if (colList.indexOf(cr) == -1)
                            {
                                col = c;
                                break;
                            }
                        }
                    }

                    row = random.nextInt(FrmGame.common.TILE_ROWS - 2);
                    /*
                    if ((col==lastcol) || (row==lastrow))
                    {
                        continue;
                    }
                    */
                    // Check if the position is occupied
                    cr = String.valueOf(col) + "-" + String.valueOf(row);
                    if (hinderList.indexOf(cr) == -1)
                    {
                        // Cross-row occupancy check
                        for (int x = 0; x < spancol; ++x)
                        {
                            isused = false;
                            for (int y = 0; y < spanrow; ++y)
                            {
                                cr = String.valueOf(col + x) + "-" + String.valueOf(row + y);
                                if (hinderList.indexOf(cr) != -1)
                                {
                                    isused = true;
                                    break;
                                }
                            }
                            if (isused)
                            {
                                break;
                            }
                        }

                        /// Randomly find a suitable location
                        if (!isused)
                        {
                            if (istrap)
                            {
                                CreateTrap(name,col, row, spancol, spanrow);
                            }
                            else
                            {
                                Hinder hinder = new Hinder(name, col, row, spancol, spanrow);
                                ImageView imgView = CreateHinder(hinder);
                                this.getChildren().add(imgView);
                            }

                            for (int x = 0; x < spancol; ++x)
                            {
                                for (int y = 0; y < spanrow; ++y)
                                {
                                    cr = String.valueOf(col + x) + "-" + String.valueOf(row + y);
                                    hinderList.add(cr);
                                    cr="-"+String.valueOf(col+x)+"-";
                                    if (colList.indexOf(cr)==-1)
                                        colList.add(cr);
                                }
                            }
                            lastrow=row;
                            lastcol=col;
                            break;
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            System.out.println("SetHinder->error:" + ex.getMessage());
        }
    }

}
