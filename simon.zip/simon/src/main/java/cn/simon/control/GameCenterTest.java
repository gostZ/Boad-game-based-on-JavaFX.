package cn.simon.control;

import cn.simon.FrmGame;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.junit.Assert;
import org.junit.Test;
import org.testfx.framework.junit.ApplicationTest;

import static org.junit.Assert.*;

public class GameCenterTest extends ApplicationTest
{
    Parent sceneRoot;
    @Override
    public void start(Stage stage)
    {
        try
        {
            FrmGame.common.InitGame();
            sceneRoot = new GameCenter(600,800);
            Scene scene = new Scene(sceneRoot, 200, 80);
            stage.setScene(scene);
            stage.show();
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }

    @Test
    public void movePlayer()
    {
    }

    @Test
    public void setHinder()
    {
    }

    @Test
    public void should_contain_pane()
    {
        Assert.assertNotNull("#tilePane");
    }

}
