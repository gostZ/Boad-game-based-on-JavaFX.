package cn.simon.control;

import cn.simon.FrmGame;
import cn.simon.PlayerEventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;

public class GameLeft extends VBox
{
    public Button btnRollA,btnRollB;
    public PlayerVBox playerA,playerB;
    public RecordVBox recordVBox;
    public GameLeft()
    {
        try
        {
            this.setStyle("-fx-background-color: #fefdfc");

            String playerNameA=FrmGame.common.playerList.get(0).name;
            playerA = new PlayerVBox(playerNameA, "", "");
            playerA.setId("playerA");
            btnRollA=new Button(playerNameA+"  Roll");
            btnRollA.setId("btnRollA");

            btnRollA.setPrefHeight(35);
            btnRollA.setPrefWidth(100);


            String playerNameB=FrmGame.common.playerList.get(1).name;
            playerB = new PlayerVBox(playerNameB, "", "");
            playerB.setId("playerB");
            btnRollB=new Button(playerNameB+"  Roll");
            btnRollB.setId("btnRollB");

            btnRollB.setPrefHeight(35);
            btnRollB.setPrefWidth(120);

            recordVBox=new RecordVBox();
            recordVBox.setId("recordVBox");
            this.setPadding(new Insets(10,0,10,10));
            this.getChildren().addAll(playerA,btnRollA,playerB,btnRollB,recordVBox);

            btnRollA.setOnAction(new PlayerEventHandler(playerNameA));
            btnRollB.setOnAction(new PlayerEventHandler(playerNameB));
            this.setId("leftPane");

        }
        catch (Exception ex)
        {
            System.out.println("GameLeft->error:"+ex.getMessage());
        }
    }
}
