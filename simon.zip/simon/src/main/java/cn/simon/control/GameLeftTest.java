package cn.simon.control;

import cn.simon.FrmGame;
import javafx.application.Application;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import org.junit.Assert;
import org.junit.Test;
import org.testfx.framework.junit.ApplicationTest;

import static org.junit.Assert.*;
import static org.testfx.api.FxAssert.verifyThat;
import static org.testfx.matcher.control.LabeledMatchers.hasText;

public class GameLeftTest extends ApplicationTest
{
    Parent sceneRoot;
    @Override
    public void start(Stage stage)
    {
        try
        {
            FrmGame.common.InitGame();
            sceneRoot = new GameLeft();
            Scene scene = new Scene(sceneRoot, 200, 80);
            stage.setScene(scene);
            stage.show();
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }

    @Test
    public void should_contain_PlayerInfoLabel()
    {
        Label lbl = (Label) lookup("#playerA").query().lookup("#lblPlayer");
        verifyThat(lbl, hasText("Jack"));

        lbl = (Label) lookup("#playerA").query().lookup("#lblDice");
        verifyThat(lbl, hasText(""));

        lbl = (Label) lookup("#playerA").query().lookup("#lblDirection");
        verifyThat(lbl, hasText(""));

        lbl = (Label) lookup("#playerB").query().lookup("#lblPlayer");
        verifyThat(lbl, hasText("Lisa"));

        lbl = (Label) lookup("#playerB").query().lookup("#lblDice");
        verifyThat(lbl, hasText(""));

        lbl = (Label) lookup("#playerB").query().lookup("#lblDirection");
        verifyThat(lbl, hasText(""));

    }

    @Test
    public void should_contain_button()
    {
        String btnText = FrmGame.common.playerList.get(0).name + "  Roll";
        verifyThat("#btnRollA", hasText(btnText));

        btnText = FrmGame.common.playerList.get(1).name + "  Roll";
        verifyThat("#btnRollB", hasText(btnText));
    }

    @Test
    public void should_contain_RecordVBox()
    {
        Assert.assertNotNull("#recordVBox");
    }

    @Test
    public void should_contain_pane()
    {
        Assert.assertNotNull("#leftPane");
    }


}
