package cn.simon.control;

import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;

public class GameTop extends AnchorPane
{
    public GameTop()
    {
        this.setStyle("-fx-background-color: #a8d18d");

        Label label=new Label("Finish  Area");
        label.setId("label");
        label.setPrefHeight(40);
        label.setAlignment(Pos.CENTER);
        label.setStyle("-fx-font-family:'Arial'; -fx-font-size: 16px");

        setTopAnchor(label,0.0);
        setLeftAnchor(label,0.0);
        setRightAnchor(label,0.0);
        setBottomAnchor(label,0.0);
        this.setId("topPane");
        this.getChildren().add(label);
    }

}
