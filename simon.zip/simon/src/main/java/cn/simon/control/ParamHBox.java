package cn.simon.control;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;

public class ParamHBox extends HBox
{
    private Label     label     =new Label();
    private TextField textField =new TextField();

    public ParamHBox(String lbltext, String fieldvalue)
    {
        label.setText(lbltext);
        label.setId("lblname");
        textField.setText(fieldvalue);
        textField.setId("txtvalue");

        label.setStyle("-fx-font-family:'Arial'");
        label.setPrefWidth(120);
        label.setFont(Font.font(14));
        textField.setPrefWidth(120);
        textField.setFont(Font.font(14));
        this.setPadding(new Insets(5,2,5,2));
        this.setSpacing(5);
        this.getChildren().addAll(label,textField);
        this.setAlignment(Pos.BASELINE_CENTER);
    }

    public void setLblText(String lbltext)
    {
        label.setText(lbltext);
    }

    public void setFieldValue(String fieldvalue)
    {
        textField.setText(fieldvalue);
    }

    public String getLblText()
    {
        return label.getText();
    }

    public String getFieldValue()
    {
        return textField.getText();
    }
}
