package cn.simon.control;

import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.junit.Test;
import org.testfx.framework.junit.ApplicationTest;
import org.testfx.matcher.control.TextInputControlMatchers;
import static org.testfx.api.FxAssert.verifyThat;
import static org.testfx.matcher.control.LabeledMatchers.hasText;

public class ParamHBoxTest extends ApplicationTest
{
    Parent sceneRoot;
    @Override
    public void start(Stage stage)
    {
        try
        {
            sceneRoot =new  ParamHBox("Player Name:","");
            Scene scene = new Scene(sceneRoot, 200, 80);
            stage.setScene(scene);
            stage.show();
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }

    @Test
    public void setLblText()
    {
    }

    @Test
    public void setFieldValue()
    {
        clickOn("#txtvalue");
        write("Jack");
        verifyThat("#txtvalue",TextInputControlMatchers.hasText("Jack"));
    }

    @Test
    public void getLblText()
    {
        verifyThat("#lblname", hasText("Player Name:"));
    }

    @Test
    public void getFieldValue()
    {
        verifyThat("#txtvalue",TextInputControlMatchers.hasText(""));
    }
}
