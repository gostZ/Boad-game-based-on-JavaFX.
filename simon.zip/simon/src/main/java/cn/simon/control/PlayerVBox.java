package cn.simon.control;

import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class PlayerVBox extends VBox
{
    private Label label_1=new Label("Player Name:");
    private Label lblPlayer=new Label("");

    private Label label_2=new Label("Dice Points:");
    private Label lblDice=new Label("");

    private Label label_3=new Label("Direction:");
    private Label lblDirection=new Label("");

    public PlayerVBox(String name,String dice,String direction)
    {
        label_1.setStyle("-fx-font-family:'Arial' ; -fx-font-size: 14");
        label_2.setStyle("-fx-font-family:'Arial' ; -fx-font-size: 14");
        label_3.setStyle("-fx-font-family:'Arial' ; -fx-font-size: 14");

        lblPlayer.setStyle("-fx-font-family:'Arial' ; -fx-font-size: 14");
        lblPlayer.setText(name);
        lblPlayer.setId("lblPlayer");

        lblDice.setStyle("-fx-font-family:'Arial' ; -fx-font-size: 14");
        lblDice.setText(dice);
        lblDice.setId("lblDice");

        lblDirection.setStyle("-fx-font-family:'Arial' ; -fx-font-size: 14");
        lblDirection.setText(direction);
        lblDirection.setId("lblDirection");

        HBox hBoxPlayer=new HBox();
        hBoxPlayer.setSpacing(5);
        hBoxPlayer.getChildren().addAll(label_1,lblPlayer);
        hBoxPlayer.setId("hBoxPlayer");

        HBox hBoxDice=new HBox();
        hBoxDice.setSpacing(5);
        hBoxDice.getChildren().addAll(label_2,lblDice);
        hBoxDice.setId("hBoxDice");

        HBox hBoxDirection=new HBox();
        hBoxDirection.setSpacing(5);
        hBoxDirection.getChildren().addAll(label_3,lblDirection);
        hBoxDirection.setId("hBoxDirection");

        this.setPadding(new Insets(10,5,10,5));
        this.setSpacing(10);
        this.getChildren().addAll(hBoxPlayer,hBoxDice,hBoxDirection);
        this.setPrefWidth(100);
    }

    public void setName(String name)
    {
        lblPlayer.setText(name);
    }

    public void setDice(String dice)
    {
        lblDice.setText(dice);
    }

    public void setDirection(String direction)
    {
        lblDirection.setText(direction);
    }

}
