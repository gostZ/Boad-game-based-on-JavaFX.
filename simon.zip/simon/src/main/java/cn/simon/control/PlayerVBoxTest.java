package cn.simon.control;

import cn.simon.FrmGame;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import org.junit.Test;
import org.testfx.framework.junit.ApplicationTest;

import static org.junit.Assert.*;
import static org.testfx.api.FxAssert.verifyThat;
import static org.testfx.matcher.control.LabeledMatchers.hasText;

public class PlayerVBoxTest extends ApplicationTest
{
    private Parent sceneRoot;
    @Override
    public void start(Stage stage)
    {
        try
        {
            sceneRoot =new PlayerVBox("Player:","","");
            Scene scene = new Scene(sceneRoot, 200, 80);
            stage.setScene(scene);
            stage.show();
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }

    @Test
    public void should_contain_PlayerInfoLabel()
    {
        Label lbl = (Label) lookup("#hBoxPlayer").query().lookup("#lblPlayer");
        verifyThat(lbl, hasText("Player:"));

        lbl = (Label) lookup("#hBoxDice").query().lookup("#lblDice");
        verifyThat(lbl, hasText(""));

        lbl = (Label) lookup("#hBoxDirection").query().lookup("#lblDirection");
        verifyThat(lbl, hasText(""));

    }


    @Test
    public void setName()
    {
    }

    @Test
    public void setDice()
    {
    }

    @Test
    public void setDirection()
    {
    }
}
