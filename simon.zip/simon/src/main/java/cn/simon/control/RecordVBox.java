package cn.simon.control;

import cn.simon.FrmGame;
import cn.simon.model.Score;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;

public class RecordVBox extends VBox
{
    private TableView<Score> table=new TableView<Score>();
    private ObservableList<Score> dataList;
    public RecordVBox()
    {
        dataList= FXCollections.observableArrayList(FrmGame.common.scoreList);
        TableColumn<Score,String>  colplayer=new TableColumn<>("player");
        TableColumn<Score,Integer> colintegral=new TableColumn<>("score");
        TableColumn<Score,Integer> colwins=new TableColumn<>("wins");
        TableColumn<Score,Integer> colrecords=new TableColumn<>("records");
        TableColumn<Score,Integer> colcells=new TableColumn<>("cells");

        colplayer.setCellValueFactory(new PropertyValueFactory<>("player"));
        colplayer.setPrefWidth(90);
        colintegral.setCellValueFactory(new PropertyValueFactory<>("integral"));
        colintegral.setPrefWidth(40);
        colwins.setCellValueFactory(new PropertyValueFactory<>("wins"));
        colwins.setPrefWidth(40);
        colrecords.setCellValueFactory(new PropertyValueFactory<>("records"));
        colrecords.setPrefWidth(40);
        colcells.setCellValueFactory(new PropertyValueFactory<>("cells"));
        colcells.setPrefWidth(40);

        table.getColumns().addAll(colplayer,colintegral,colwins,colrecords,colcells);
        this.setPadding(new Insets(20, 0, 0, 0));

        colwins.setSortType(TableColumn.SortType.DESCENDING);
        table.getSortOrder().add(colintegral);

        Label lblRecord=new Label(" Race Result:");
        lblRecord.setId("lblRecord");
        lblRecord.setStyle("-fx-font-family:'Arial' ; -fx-font-size: 14");
        table.setItems(dataList);
        table.setId("table");
        this.getChildren().addAll(lblRecord,table);
    }

    public void RefreshTable()
    {
        table.setItems(null);
        table.setItems(dataList);
        table.sort();
        table.refresh();
    }
}
