package cn.simon.control;

import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import org.junit.Assert;
import org.junit.Test;
import org.testfx.framework.junit.ApplicationTest;

import static org.junit.Assert.*;
import static org.testfx.api.FxAssert.verifyThat;
import static org.testfx.matcher.control.LabeledMatchers.hasText;

public class RecordVBoxTest extends ApplicationTest
{
    private Parent sceneRoot;
    @Override
    public void start(Stage stage)
    {
        try
        {
            sceneRoot =new RecordVBox();
            Scene scene = new Scene(sceneRoot, 200, 80);
            stage.setScene(scene);
            stage.show();
        }
        catch (Exception ex)
        {
            System.out.println(ex.getMessage());
        }
    }

    @Test
    public void should_contain_Label()
    {
        verifyThat("#lblRecord", hasText(" Race Result:"));
    }

    @Test
    public void should_contain_Table()
    {
        Assert.assertNotNull("#table");
    }


}
