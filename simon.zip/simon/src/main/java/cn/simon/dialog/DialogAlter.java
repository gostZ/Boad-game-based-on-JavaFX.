package cn.simon.dialog;

import javafx.scene.control.Alert;

public class DialogAlter
{

    public static void show(String msg)
    {
        try
        {
            Alert alert=new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Attention");;
            alert.setHeaderText("");
            alert.setContentText(msg);
            alert.showAndWait();
        }
        catch (Exception ex){}
    }
}
