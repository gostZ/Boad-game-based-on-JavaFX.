package cn.simon.dialog;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class DialogConfirm
{
    public static boolean show(String msg)
    {
        final Boolean[] answer = {false};
        Stage window=new Stage();
        window.setTitle("Please Select");

        Button btnOk=new Button("Ok");
        Button btnCancel=new Button("Cancel");

        btnOk.setPrefWidth(60);
        btnOk.setPrefHeight(30);

        btnCancel.setPrefWidth(60);
        btnCancel.setPrefHeight(30);

        Label lblMsg=new Label(msg);

        btnOk.setOnAction(actionEvent -> {
            answer[0]=true;
            window.close();
        } );

        btnCancel.setOnAction(actionEvent -> {
            window.close();
        });

        HBox hBox=new HBox(50);
        hBox.getChildren().addAll(btnOk,btnCancel);
        hBox.setAlignment(Pos.BOTTOM_CENTER);
        hBox.setPrefHeight(80);

        VBox vBox=new VBox();
        vBox.setPadding(new Insets(20,10,20,20));
        vBox.setSpacing(20);

        vBox.getChildren().addAll(lblMsg,hBox);
        Scene scene=new Scene(vBox,350,150);
        window.setScene(scene);
        window.initStyle(StageStyle.UTILITY);
        window.showAndWait();

        return answer[0];
    }
}
