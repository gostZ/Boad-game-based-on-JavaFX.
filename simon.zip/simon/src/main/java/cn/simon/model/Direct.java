package cn.simon.model;

public enum Direct
{
    //Moving forward
    Forward,
    //Backward
    Recede,
    //miss a turn
    NoTurn
}
