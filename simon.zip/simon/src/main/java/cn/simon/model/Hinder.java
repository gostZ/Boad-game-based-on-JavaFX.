package cn.simon.model;

public class Hinder
{
    /**
     * name : The name of the obstacle (this name is the same as the name of the picture it is bound to)
     * col : Columns of the grid
     * spancol : Number of columns across the grid
     * row : Row of the grid
     * spanrow : Number of rows across the grid
     * */

    // The name of the obstacle (this name is the same as the name of the picture it is bound to)
    public String name;
    ///Columns of the grid
    public int col;

    // Number of columns across the grid
    public int spancol;
    /// Row of the grid
    public int row;
    /// Number of rows across the grid
    public int spanrow;

    public Hinder(String name,int col,int row,int spancol,int spanrow)
    {
        this.name   =name;
        this.col    =col;
        this.row    =row;
        this.spancol=spancol;
        this.spanrow=spanrow;
    }

}

