package cn.simon.model;


import java.util.ArrayList;

public class MoveResult
{
    /**
     * row : Grid's Row
     * col : Columns of the grid
     * isTrap : Trigger special obstacles
     * isOver : game's over
     * cells : Number of squares moved this time
     * moveLines : Move routes
     * */
    // Grid's Row
    public int row=-1;
    // Columns of the grid
    public int col=-1;
    // Trigger special obstacles
    public boolean isTrap=false;
    // game's over
    public boolean isOver   =false;
    // Number of squares moved this time
    public int cells;
    // Move routes
    public ArrayList<Point> moveLines=new ArrayList<>();
}
