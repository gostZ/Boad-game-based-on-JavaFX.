package cn.simon.model;

public class Player
{
    /**
     * name : Player's name
     * col : Column of location
     * row : When row equals to the maximum number of rows in the grid, the player is at the starting point.
     * records : Number of games played this time
     * wins : Number of games played and won this time
     * cells : Number of squares moved per game
     * imghead : Player image name
     * isTrap : Determine if the player is currently in a trap
     * noTurn : Number of turns required to be in a trap
     * */
    ///Player's name
    public String name;
    /// Column of location
    public int col=-1;
    // When row equals to the maximum number of rows in the grid, the player is at the starting point.
    public int row=-1;
     public int records;
    //Number of games played and won this time
    public int wins;
    // Number of squares moved per game
    public int cells;
    /// Player image name
    public String imghead;
    // Determine if the player is currently in a trap
    public Boolean isTrap=false;
    // Number of turns required to be in a trap
    public int noTurn;

    public Player(String name,int col,int row,String imghead)
    {
        this.name   =name;
        this.col    =col;
        this.row    =row;
        this.imghead=imghead;
    }

}
