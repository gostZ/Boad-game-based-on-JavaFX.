package cn.simon.model;

/**
 * Player Match Results Storage Classes
 * */
public class Score implements Comparable<Score>
{
    // player name
    public String player="";
    // score of game
    public int  integral=0;
    // number of win
    public int  wins=0;
    // number of game
    public int  records=0;
    // Number of moving squares
    public int  cells=0;

    public String getPlayer()
    {
        return this.player;
    }
    public int getIntegral()
    {
        return this.integral;
    }
    public int getWins()
    {
        return this.wins;
    }
    public int getRecords()
    {
        return this.records;
    }
    public int getCells()
    {
        return this.cells;
    }


    /**
     * Player Point Ranking Method
     * */
    @Override
    public int compareTo(Score other)
    {
        if (integral>other.integral)
            return -1;
        else if (integral<other.integral)
        {
                return 1;
        }
        return 0;
    }

    /**
     * Scoring of Players' Endgame Results
     * */
    public void grade()
    {
        this.integral=(int)( ( ((double)wins/records)*100) * ((double)records/cells)*10);
    }

}
