package cn.simon.model;

import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class Tile extends Rectangle
{
    /// Store the object currently placed in the grid (Hinder, Player)
    private Object placeObject = null;

    /// Storage object is an obstacle marker
    private boolean isHinder=true;

    /// Is the cell marked with a trap
    private boolean isTrap=false;

    public Tile(boolean light, int col, int row, int tilewidth, int tileheight)
    {
        setWidth(tilewidth);
        setHeight(tileheight);
        relocate(col * tilewidth, row * tileheight);
        //setting colour
        setFill(light ? Color.valueOf("#d0d5eb") : Color.valueOf("#e9ecf5"));
    }

    public boolean hasObject()
    {
        return placeObject != null;
    }

    public Object getObject()
    {
        return placeObject;
    }

    public void setObject(Object placeObject,boolean ishinder)
    {
        this.placeObject = placeObject;
        this.isHinder    =ishinder;
    }

    public boolean hasTrap()
    {
        return isTrap;
    }

    public void setTrap(boolean istrap)
    {
        this.isTrap=istrap;
    }
}
