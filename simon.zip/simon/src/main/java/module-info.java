module cn.simon.simon {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;
    requires junit;
    requires org.junit.jupiter.api;
    requires org.testfx.junit;
    requires org.testfx;

    exports cn.simon;
    opens cn.simon to javafx.fxml;

    exports cn.simon.control;
    opens cn.simon.control to javafx.fxml;

    exports cn.simon.dialog;
    opens cn.simon.dialog to javafx.fxml;

    exports cn.simon.model;
    opens cn.simon.model to javafx.fxml;

}
